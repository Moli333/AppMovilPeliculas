const Colors = {
    background: '#1E1E1E',
    black: '#000000',
    white: '#ffffff',
    lightGray: '#ccc',
    primary: '#4481FC',
    danger: '#F5365C',
  };
  
  export default Colors;